xxx = true

function xx(str)
	if xxx then
		print(serpent.block(str))
	end
end

require "prototypes.export_items"
require "prototypes.export_recipes"
require "prototypes.export_furnaces"
require "prototypes.export_tech"